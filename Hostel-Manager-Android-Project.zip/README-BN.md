# Hostel Manager Android

এটি একটি Expo/React Native Android project। এতে স্থানীয়ভাবে (এই ফোনে) মাসভিত্তিক সদস্য, জমা, খরচ, মিল এবং রিপোর্ট রাখা যায়।

## APK build
1. Node.js 20.19.4 বা নতুন সংস্করণ লাগবে।
2. `npm install`
3. `npm install -g eas-cli`
4. `eas login`
5. `eas build -p android --profile preview`

`eas.json`-এর preview profile APK তৈরি করার জন্য সেট করা আছে।

## গুরুত্বপূর্ণ
এই সংস্করণে ডেটা AsyncStorage দিয়ে ফোনে থাকে। অনলাইন Supabase sync, একাধিক ডিভাইসের sync, Owner/Manager authentication এবং cloud backup এখনো যুক্ত নয়। অ্যাপের ডেটা clear/uninstall করলে ডেটা হারাতে পারে। বাস্তব আর্থিক হিসাবের আগে backup ও security review প্রয়োজন।
