import React, { useEffect, useMemo, useState } from "react";
import { Alert, SafeAreaView, ScrollView, StatusBar, Text, TextInput, TouchableOpacity, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const GREEN = "#137a4a";
const BG = "#f1f7f3";
const STORE = "hostel-manager-v1";
const pad = n => String(n).padStart(2, "0");
const monthKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}`;
const monthLabel = key => {
  const [y,m] = key.split("-").map(Number);
  return new Date(y,m-1,1).toLocaleDateString("en-US",{month:"long",year:"numeric"});
};
const freshMonth = () => ({ members: [], deposits: [], expenses: [], meals: [], closed: false });

export default function App() {
  const [db,setDb] = useState({});
  const [month,setMonth] = useState(monthKey(new Date()));
  const [tab,setTab] = useState("জমা");
  const [name,setName] = useState("");
  const [amount,setAmount] = useState("");
  const [note,setNote] = useState("");
  const [selected,setSelected] = useState("");
  const [mealCount,setMealCount] = useState("1");
  const [ready,setReady] = useState(false);

  useEffect(() => {
    (async()=>{
      try {
        const raw = await AsyncStorage.getItem(STORE);
        if(raw) setDb(JSON.parse(raw));
      } catch(e) { Alert.alert("তথ্য পড়া যায়নি","অ্যাপের ডেটা লোড করতে সমস্যা হয়েছে।"); }
      setReady(true);
    })();
  },[]);
  useEffect(() => { if(ready) AsyncStorage.setItem(STORE,JSON.stringify(db)).catch(()=>{}); },[db,ready]);

  const data = db[month] || freshMonth();
  const members = data.members || [];
  const totalDeposit = (data.deposits||[]).reduce((s,x)=>s+Number(x.amount||0),0);
  const marketExpense = (data.expenses||[]).filter(x=>x.type==="বাজার").reduce((s,x)=>s+Number(x.amount||0),0);
  const otherExpense = (data.expenses||[]).filter(x=>x.type!=="বাজার").reduce((s,x)=>s+Number(x.amount||0),0);
  const totalExpense = marketExpense + otherExpense;
  const totalMeals = (data.meals||[]).reduce((s,x)=>s+Number(x.count||0),0);
  const balance = totalDeposit-totalExpense;
  const update = patch => setDb(prev=>({...prev,[month]:{...(prev[month]||freshMonth()),...patch}}));
  const ensureOpen = () => { if(data.closed){Alert.alert("মাস বন্ধ","এই মাসের হিসাব CLOSED। পরিবর্তন করতে আগে Reopen করতে হবে।"); return false;} return true; };
  const addMember = () => {
    if(!ensureOpen()) return;
    const v=name.trim(); if(!v) return Alert.alert("নাম লিখুন");
    if(members.some(m=>m.name.toLowerCase()===v.toLowerCase())) return Alert.alert("এই সদস্য আগে থেকেই আছে");
    const id=String(Date.now()); update({members:[...members,{id,name:v}]}); setName(""); setSelected(id);
  };
  const addDeposit = () => {
    if(!ensureOpen()) return;
    const n=Number(amount); if(!selected) return Alert.alert("সদস্য নির্বাচন করুন");
    if(!Number.isFinite(n)||n<=0) return Alert.alert("সঠিক টাকার পরিমাণ লিখুন");
    update({deposits:[...(data.deposits||[]),{id:String(Date.now()),memberId:selected,amount:n,date:new Date().toISOString(),note:note.trim()}]});
    setAmount("");setNote("");Alert.alert("সফল","জমা যোগ হয়েছে");
  };
  const addExpense = type => {
    if(!ensureOpen()) return;
    const n=Number(amount); if(!Number.isFinite(n)||n<=0) return Alert.alert("সঠিক টাকার পরিমাণ লিখুন");
    update({expenses:[...(data.expenses||[]),{id:String(Date.now()),type,amount:n,date:new Date().toISOString(),note:note.trim()}]});
    setAmount("");setNote("");Alert.alert("সফল","খরচ যোগ হয়েছে");
  };
  const addMeal = () => {
    if(!ensureOpen()) return;
    if(!selected) return Alert.alert("সদস্য নির্বাচন করুন");
    const n=Number(mealCount); if(!Number.isFinite(n)||n<0) return Alert.alert("সঠিক মিল সংখ্যা লিখুন");
    update({meals:[...(data.meals||[]),{id:String(Date.now()),memberId:selected,count:n,date:new Date().toISOString()}]});
    setMealCount("1");Alert.alert("সফল","মিল যোগ হয়েছে");
  };
  const changeMonth = dir => {
    const [y,m]=month.split("-").map(Number); const d=new Date(y,m-1+dir,1); setMonth(monthKey(d));
  };
  const closeMonth = () => {
    if(data.closed) return Alert.alert("মাস CLOSED","এই মাস ইতিমধ্যে বন্ধ।");
    Alert.alert("মাস বন্ধ করবেন?","এই মাসের হিসাব বন্ধ হলে আর পরিবর্তন করা যাবে না।",[
      {text:"বাতিল",style:"cancel"},{text:"CLOSED করুন",style:"destructive",onPress:()=>update({closed:true})}
    ]);
  };
  const reopenMonth = () => Alert.alert("Reopen করবেন?","এই মাসের হিসাব আবার সম্পাদনার জন্য খুলবে।",[
    {text:"বাতিল",style:"cancel"},{text:"Reopen",onPress:()=>update({closed:false})}
  ]);
  const memberName = id => members.find(m=>m.id===id)?.name || "সদস্য মুছে ফেলা হয়েছে";

  const Card = ({label,value}) => <View style={styles.card}><Text style={styles.muted}>{label}</Text><Text style={styles.metric}>{value}</Text></View>;
  const Btn = ({title,onPress,active=false,disabled=false}) => <TouchableOpacity onPress={onPress} disabled={disabled} style={[styles.btn,active&&styles.btnActive,disabled&&{opacity:.45}]}><Text style={[styles.btnText,active&&{color:"#fff"}]}>{title}</Text></TouchableOpacity>;
  const Field = ({value,onChangeText,placeholder,keyboardType}) => <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} keyboardType={keyboardType||"default"} style={styles.input} placeholderTextColor="#89958e"/>;
  const recordList = (arr,render) => arr.length ? arr.slice().reverse().map(x=><View key={x.id} style={styles.record}>{render(x)}</View>) : <Text style={styles.muted}>এখনো কোনো তথ্য যোগ করা হয়নি।</Text>;

  if(!ready) return <SafeAreaView style={styles.safe}><Text style={styles.title}>Hostel Manager লোড হচ্ছে…</Text></SafeAreaView>;

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={GREEN}/>
    <ScrollView>
      <View style={styles.header}>
        <Text style={styles.title}>🏠 Hostel Manager</Text>
        <Text style={styles.subtitle}>হোস্টেলের মাসিক হিসাব ব্যবস্থাপনা</Text>
        <View style={styles.monthRow}>
          <Btn title="‹" onPress={()=>changeMonth(-1)}/>
          <Text style={styles.monthText}>{monthLabel(month)}</Text>
          <Btn title="›" onPress={()=>changeMonth(1)}/>
        </View>
      </View>
      <View style={styles.body}>
        <View style={styles.sectionHead}><Text style={styles.heading}>{monthLabel(month)} সারাংশ</Text><Text style={[styles.status,data.closed?styles.closed:styles.open]}>{data.closed?"CLOSED":"চলমান"}</Text></View>
        <View style={styles.grid}>
          <Card label="মোট সদস্য" value={`${members.length} জন`}/>
          <Card label="মোট মিল" value={`${totalMeals}`}/>
          <Card label="বাজার খরচ" value={`৳ ${marketExpense.toLocaleString("en-US")}`}/>
          <Card label="অন্যান্য খরচ" value={`৳ ${otherExpense.toLocaleString("en-US")}`}/>
          <Card label="মোট জমা" value={`৳ ${totalDeposit.toLocaleString("en-US")}`}/>
          <Card label="Cash Balance" value={`৳ ${balance.toLocaleString("en-US")}`}/>
        </View>
        <View style={styles.tabs}>{["জমা","খরচ","মিল","সদস্য","রিপোর্ট"].map(t=><Btn key={t} title={t} active={tab===t} onPress={()=>setTab(t)}/>)}</View>
        {tab==="সদস্য" && <View style={styles.panel}>
          <Text style={styles.panelTitle}>👥 সদস্য যোগ</Text>
          <Field value={name} onChangeText={setName} placeholder="সদস্যের নাম লিখুন"/>
          <Btn title="সদস্য যোগ করুন" onPress={addMember} disabled={data.closed}/>
          <Text style={styles.subhead}>সদস্য তালিকা ({members.length})</Text>
          {recordList(members,m=><Text style={styles.recordText}>{m.name}</Text>)}
        </View>}
        {tab==="জমা" && <View style={styles.panel}>
          <Text style={styles.panelTitle}>💰 টাকা জমা</Text>
          <Text style={styles.label}>সদস্য</Text>
          {members.map(m=><Btn key={m.id} title={m.name} active={selected===m.id} onPress={()=>setSelected(m.id)}/>)}
          <Text style={styles.label}>টাকার পরিমাণ (৳)</Text><Field value={amount} onChangeText={setAmount} placeholder="যেমন ২০০০" keyboardType="numeric"/>
          <Field value={note} onChangeText={setNote} placeholder="বিবরণ (ঐচ্ছিক)"/>
          <Btn title="জমা যোগ করুন" onPress={addDeposit} disabled={data.closed}/>
          <Text style={styles.subhead}>জমার তালিকা</Text>
          {recordList(data.deposits||[],x=><><Text style={styles.recordText}>{memberName(x.memberId)} · ৳{x.amount}</Text><Text style={styles.muted}>{new Date(x.date).toLocaleDateString("en-GB")}</Text></>)}
        </View>}
        {tab==="খরচ" && <View style={styles.panel}>
          <Text style={styles.panelTitle}>🧾 খরচ যোগ</Text>
          <Text style={styles.label}>টাকার পরিমাণ (৳)</Text><Field value={amount} onChangeText={setAmount} placeholder="যেমন ৫০০" keyboardType="numeric"/>
          <Field value={note} onChangeText={setNote} placeholder="বিবরণ / বাজারের নাম"/>
          <View style={styles.row}><Btn title="বাজার খরচ যোগ" onPress={()=>addExpense("বাজার")} disabled={data.closed}/><Btn title="অন্যান্য খরচ যোগ" onPress={()=>addExpense("অন্যান্য")} disabled={data.closed}/></View>
          <Text style={styles.subhead}>খরচের তালিকা</Text>
          {recordList(data.expenses||[],x=><><Text style={styles.recordText}>{x.type} · ৳{x.amount}</Text><Text style={styles.muted}>{x.note||new Date(x.date).toLocaleDateString("en-GB")}</Text></>)}
        </View>}
        {tab==="মিল" && <View style={styles.panel}>
          <Text style={styles.panelTitle}>🍽️ মিল যোগ</Text>
          <Text style={styles.label}>সদস্য নির্বাচন করুন</Text>
          {members.map(m=><Btn key={m.id} title={m.name} active={selected===m.id} onPress={()=>setSelected(m.id)}/>)}
          <Text style={styles.label}>মিল সংখ্যা</Text><Field value={mealCount} onChangeText={setMealCount} placeholder="1" keyboardType="numeric"/>
          <Btn title="মিল যোগ করুন" onPress={addMeal} disabled={data.closed}/>
          <Text style={styles.subhead}>মিলের তালিকা</Text>
          {recordList(data.meals||[],x=><Text style={styles.recordText}>{memberName(x.memberId)} · {x.count} মিল · {new Date(x.date).toLocaleDateString("en-GB")}</Text>)}
        </View>}
        {tab==="রিপোর্ট" && <View style={styles.panel}>
          <Text style={styles.panelTitle}>📊 মাসিক রিপোর্ট</Text>
          {[
            ["মোট জমা",totalDeposit],["বাজার খরচ",marketExpense],["অন্যান্য খরচ",otherExpense],["মোট খরচ",totalExpense],["Cash Balance",balance],["মোট মিল",totalMeals]
          ].map(([k,v])=><View key={k} style={styles.reportRow}><Text style={styles.recordText}>{k}</Text><Text style={styles.recordText}>{k==="মোট মিল"?v:`৳ ${Number(v).toLocaleString("en-US")}`}</Text></View>)}
          <Text style={styles.subhead}>মাসের অবস্থা: {data.closed?"CLOSED":"চলমান"}</Text>
          {data.closed?<Btn title="মাস Reopen করুন" onPress={reopenMonth}/>:<Btn title="মাস CLOSED করুন" onPress={closeMonth}/>}
          <Text style={styles.muted}>প্রতিটি মাসের হিসাব আলাদা রাখা হয়। নতুন মাসে আগের মাসের জমা বা Cash Balance যোগ হয় না।</Text>
        </View>}
        <Text style={styles.footer}>ডেটা এই ফোনে সংরক্ষিত থাকে। অ্যাপের ডেটা Clear বা Uninstall করলে হারাতে পারে—নিয়মিত Backup ব্যবস্থা যোগ না হওয়া পর্যন্ত সতর্ক থাকুন।</Text>
      </View>
    </ScrollView>
  </SafeAreaView>;
}

const styles = {
 safe:{flex:1,backgroundColor:BG}, header:{backgroundColor:GREEN,padding:22,paddingTop:28,borderBottomLeftRadius:28,borderBottomRightRadius:28},
 title:{fontSize:25,fontWeight:"800",color:"#fff"}, subtitle:{fontSize:15,color:"#d8eee2",marginTop:6},
 monthRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:22},monthText:{color:"#fff",fontSize:17,fontWeight:"700"},
 body:{padding:16},sectionHead:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:12},heading:{fontSize:20,fontWeight:"800",color:"#18251e"},
 status:{paddingHorizontal:12,paddingVertical:6,borderRadius:20,fontWeight:"700",overflow:"hidden"},open:{backgroundColor:"#d9f3e3",color:GREEN},closed:{backgroundColor:"#ffe2e2",color:"#a52a2a"},
 grid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between"},card:{width:"48.5%",backgroundColor:"#fff",padding:16,borderRadius:18,marginBottom:12,borderWidth:1,borderColor:"#e2ebe5",minHeight:92,justifyContent:"center"},
 muted:{color:"#718078",fontSize:13,marginTop:4},metric:{fontSize:22,fontWeight:"800",color:GREEN,marginTop:8},
 tabs:{flexDirection:"row",flexWrap:"wrap",gap:7,marginVertical:10},btn:{backgroundColor:"#fff",borderColor:"#dce7df",borderWidth:1,borderRadius:13,paddingVertical:11,paddingHorizontal:14,alignItems:"center",justifyContent:"center",marginBottom:6},
 btnActive:{backgroundColor:GREEN,borderColor:GREEN},btnText:{color:"#28533d",fontWeight:"700",fontSize:14},
 panel:{backgroundColor:"#fff",padding:17,borderRadius:20,borderWidth:1,borderColor:"#e0e9e3",marginTop:8},panelTitle:{fontSize:20,fontWeight:"800",color:"#17251d",marginBottom:12},
 input:{borderWidth:1,borderColor:"#dce6df",borderRadius:13,paddingHorizontal:14,paddingVertical:12,fontSize:16,color:"#1c2a22",marginBottom:10,backgroundColor:"#fbfdfb"},
 label:{fontSize:14,fontWeight:"700",color:"#53645a",marginBottom:7,marginTop:5},subhead:{fontSize:16,fontWeight:"800",color:"#26382e",marginTop:16,marginBottom:8},
 record:{paddingVertical:10,borderBottomWidth:1,borderBottomColor:"#edf1ee"},recordText:{fontSize:15,color:"#26382e",fontWeight:"600"},row:{flexDirection:"row",gap:8,flexWrap:"wrap"},reportRow:{flexDirection:"row",justifyContent:"space-between",paddingVertical:10,borderBottomWidth:1,borderBottomColor:"#edf1ee"},
 footer:{color:"#7c8981",fontSize:12,lineHeight:18,marginTop:18,marginBottom:28}
};
